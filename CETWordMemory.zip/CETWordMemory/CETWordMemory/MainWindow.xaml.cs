﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace CETWordMemory
{
    // StartupMode enum is defined in IntroWindow.xaml.cs (same namespace)

    public partial class MainWindow : Window
    {
        // 智谱清言API v4 配置
        private readonly string apiKey = "3ab401aa80814abd82f4bfae22e841fb.kHLZvyXJARjoi37G";//api密钥
        private readonly string textApiEndpoint = "https://open.bigmodel.cn/api/paas/v4/chat/completions";//文字URL地址
        private readonly string imageApiEndpoint = "https://open.bigmodel.cn/api/paas/v4/images/generations";//图片URL地址
        private readonly string modelName = "glm-4-flash-250414";//文字模型选用
        private readonly string imageModelName = "cogview-4-250304";//图片模型选用

        // Data Collections
        private List<WordItem> wordList;
        private ObservableCollection<WordItem> mistakeList;
        private int currentLearnIndex = 0;

        // Utilities
        private readonly HttpClient httpClient;
        private Random random = new Random();

        // Test Mode State
        private WordItem currentTestWord;
        private int correctAnswers = 0;
        private int totalQuestionsAnswered = 0;

        // Field to store the initial mode
        private StartupMode _initialMode = StartupMode.Learn;

        // Constructor that accepts StartupMode
        public MainWindow(StartupMode startupMode)
        {
            InitializeComponent();

            _initialMode = startupMode;

            if (apiKey == "YOUR_API_KEY" || apiKey.Length < 10)
            {
                ShowError("API密钥未设置", "请在 MainWindow.xaml.cs 文件中第23行附近设置有效的智谱AI API密钥。应用程序可能无法正常获取单词。");
            }

            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            httpClient.Timeout = TimeSpan.FromSeconds(60);

            wordList = new List<WordItem>();
            mistakeList = new ObservableCollection<WordItem>();
            Console.WriteLine("[数据策略] 以全新状态启动，不加载先前数据。");

            lvWrongWords.ItemsSource = mistakeList;
            UpdateMistakeListControls();
            UpdateWordCountStatus();
            ClearLearnWordDisplay();
            SetLearnControlsEnabled(false);
            btnNewWord.IsEnabled = true;

            this.Loaded += MainWindow_Loaded_WithMode;
        }

        private async void MainWindow_Loaded_WithMode(object sender, RoutedEventArgs e)
        {
            this.Loaded -= MainWindow_Loaded_WithMode;

            // Set initial tab based on the startup mode
            switch (_initialMode)
            {
                case StartupMode.Learn:
                    if (mainTabControl.Items.Count > 0) mainTabControl.SelectedIndex = 0;
                    break;
                case StartupMode.Test:
                    if (mainTabControl.Items.Count > 1) mainTabControl.SelectedIndex = 1;
                    // PrepareFirstTestQuestion(); // Will be called by SelectionChanged
                    break;
                case StartupMode.Mistakes:
                    if (mainTabControl.Items.Count > 2) mainTabControl.SelectedIndex = 2;
                    break;
                default:
                    if (mainTabControl.Items.Count > 0) mainTabControl.SelectedIndex = 0;
                    break;
            }

            // If TabControl's SelectionChanged doesn't fire immediately for the pre-selected index,
            // you might need to manually trigger the setup for Test/Mistakes mode here.
            // Example: if (_initialMode == StartupMode.Test) PrepareFirstTestQuestion();
            // However, setting SelectedIndex usually triggers SelectionChanged.

            if (!wordList.Any())
            {
                UpdateStatus("正在准备第一个单词...");
                await GenerateNewWordAndDisplay();
            }
            else if (wordList.Any() && currentLearnIndex >= 0 && currentLearnIndex < wordList.Count)
            {
                if (mainTabControl.SelectedIndex == 0) // Only if learn tab is active
                {
                    DisplayCurrentLearnWord();
                    UpdateStatus($"准备就绪. 当前单词: {wordList[currentLearnIndex].Word}");
                }
            }
        }

        public class WordItem
        {
            public string Word { get; set; }
            public string Phonetic { get; set; }
            public string ChineseDefinition { get; set; }
            public string Example { get; set; }
            public string ImageUrl { get; set; }
            public DateTime LearningDate { get; set; }
            public bool IsKnown { get; set; } = false;
            public int TimesIncorrect { get; set; } = 0;

            [JsonIgnore] public string WordText => Word;
            [JsonIgnore] public string Definition => ChineseDefinition;
        }

        public class WordInfoFromApi
        {
            [JsonPropertyName("word")] public string Word { get; set; }
            [JsonPropertyName("phonetic")] public string Phonetic { get; set; }
            [JsonPropertyName("chineseDefinition")] public string ChineseDefinition { get; set; }
            [JsonPropertyName("example")] public string Example { get; set; }
            [JsonPropertyName("imageDescription")] public string ImageDescription { get; set; }
        }

        public class ZhipuV4TextResponse { public string id { get; set; } public long created { get; set; } public string model { get; set; } public ZhipuV4Choice[] choices { get; set; } public ZhipuV4Usage usage { get; set; } }
        public class ZhipuV4Choice { public int index { get; set; } public ZhipuV4Message message { get; set; } public string finish_reason { get; set; } }
        public class ZhipuV4Message { public string role { get; set; } public string content { get; set; } }
        public class ZhipuV4Usage { public int prompt_tokens { get; set; } public int completion_tokens { get; set; } public int total_tokens { get; set; } }


        #region --- 学习模式 ---
        private void DisplayCurrentLearnWord()
        {
            if (wordList.Count == 0 || currentLearnIndex < 0 || currentLearnIndex >= wordList.Count)
            {
                ClearLearnWordDisplay();
                SetLearnControlsEnabled(false);
                btnNewWord.IsEnabled = true;
                UpdateStatus("词库中没有单词。请生成新单词。");
                return;
            }

            var word = wordList[currentLearnIndex];
            txtWord.Text = word.Word;
            txtPhonetic.Text = word.Phonetic ?? "[N/A]";
            txtChineseDefinition.Text = $"释义: {word.ChineseDefinition ?? "无释义"}";
            txtExample.Text = $"例句: {word.Example ?? "无例句"}";
            txtChineseDefinition.Visibility = Visibility.Visible;

            LoadImage(word.ImageUrl, imgWord, txtImageLoading);

            btnMarkKnown.Content = word.IsKnown ? "标记未掌握" : "我会了";
            SetLearnControlsEnabled(true);
            btnNewWord.IsEnabled = true;

            UpdateStatus($"学习模式: {word.Word} ({currentLearnIndex + 1}/{wordList.Count})");
        }

        private void ClearLearnWordDisplay()
        {
            txtWord.Text = "Word";
            txtPhonetic.Text = "[Phonetic]";
            txtChineseDefinition.Text = "释义将在此显示...";
            txtChineseDefinition.Visibility = Visibility.Visible;
            txtExample.Text = "例句将在此显示...";
            imgWord.Source = new BitmapImage(new Uri("https://picsum.photos/600/150?text=CET+Word+Memory"));
            if (txtImageLoading != null) txtImageLoading.Visibility = Visibility.Collapsed;
        }

        private void SetLearnControlsEnabled(bool enableWordDependentControls)
        {
            btnPrevious.IsEnabled = enableWordDependentControls && wordList.Count > 1;
            btnNext.IsEnabled = enableWordDependentControls && wordList.Count > 1;
            btnMarkKnown.IsEnabled = enableWordDependentControls;
            btnAddToMistakes.IsEnabled = enableWordDependentControls;
        }

        private async Task GenerateNewWordAndDisplay()
        {
            ShowLoading("正在生成新单词...");
            btnNewWord.IsEnabled = false;
            SetLearnControlsEnabled(false);
            try
            {
                WordItem newWordItem = null;
                int attempts = 0;
                const int maxAttempts = 3;

                while (attempts < maxAttempts)
                {
                    attempts++;
                    UpdateLoadingMessage($"正在生成新单词 (尝试 {attempts}/{maxAttempts})...");
                    var candidateWord = await GetWordFromZhipu();
                    if (candidateWord != null)
                    {
                        if (!wordList.Any(w => w.Word.Equals(candidateWord.Word, StringComparison.OrdinalIgnoreCase)))
                        {
                            newWordItem = candidateWord;
                            break;
                        }
                        else
                        {
                            Console.WriteLine($"[生成重复单词] 单词 '{candidateWord.Word}' 已存在，尝试重新生成。");
                        }
                    }
                    else { break; } // API call failed, break attempts
                    if (attempts < maxAttempts) await Task.Delay(TimeSpan.FromMilliseconds(500));
                }

                if (newWordItem != null)
                {
                    wordList.Add(newWordItem);
                    currentLearnIndex = wordList.Count - 1;
                    DisplayCurrentLearnWord();
                    UpdateWordCountStatus();
                }
                else if (attempts >= maxAttempts && newWordItem != null && wordList.Any(w => w.Word.Equals(newWordItem.Word, StringComparison.OrdinalIgnoreCase))) // Duplicate after max attempts
                {
                    ShowError("生成单词失败", $"尝试 {maxAttempts} 次后未能获取到新的、不重复的单词。请稍后再试。");
                    UpdateStatus("未能生成不重复的新单词。");
                    if (!wordList.Any()) ClearLearnWordDisplay(); else DisplayCurrentLearnWord(); // Show existing if any
                }
                else // Other failures (e.g. API error during GetWordFromZhipu)
                {
                    UpdateStatus("生成新单词失败，请查看错误提示。");
                    if (!wordList.Any()) ClearLearnWordDisplay(); else DisplayCurrentLearnWord(); // Show existing if any
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[GenerateNewWordAndDisplay Error] {ex}");
                ShowError("生成单词严重错误", $"处理新单词时发生意外: {ex.Message}");
                UpdateStatus("生成新单词时出错。");
                if (!wordList.Any()) ClearLearnWordDisplay();
            }
            finally
            {
                HideLoading();
                btnNewWord.IsEnabled = true;
                SetLearnControlsEnabled(wordList.Any());
            }
        }

        private void BtnPrevious_Click(object sender, RoutedEventArgs e)
        {
            if (wordList.Count > 0)
            {
                currentLearnIndex = (currentLearnIndex - 1 + wordList.Count) % wordList.Count;
                DisplayCurrentLearnWord();
            }
        }

        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {
            if (wordList.Count > 0)
            {
                currentLearnIndex = (currentLearnIndex + 1) % wordList.Count;
                DisplayCurrentLearnWord();
            }
        }

        private async void BtnNewWord_Click(object sender, RoutedEventArgs e)
        {
            await GenerateNewWordAndDisplay();
        }

        private void BtnMarkKnown_Click(object sender, RoutedEventArgs e)
        {
            if (wordList.Count == 0 || currentLearnIndex < 0 || currentLearnIndex >= wordList.Count) return;
            var word = wordList[currentLearnIndex];
            word.IsKnown = !word.IsKnown;
            btnMarkKnown.Content = word.IsKnown ? "标记未掌握" : "我会了";
            UpdateStatus($"单词 '{word.Word}' 已标记为 {(word.IsKnown ? "已掌握" : "未掌握")}");
            UpdateWordCountStatus();
        }

        private void BtnAddToMistakes_Click(object sender, RoutedEventArgs e)
        {
            if (wordList.Count == 0 || currentLearnIndex < 0 || currentLearnIndex >= wordList.Count) return;
            AddWordToMistakes(wordList[currentLearnIndex]);
        }
        #endregion

        #region --- 测试模式 ---
        private void PrepareFirstTestQuestion()
        {
            if (!wordList.Any())
            {
                txtTestQuestion.Text = "词库为空，无法开始测试。请先在“学习模式”添加单词。";
                txtTestQuestionType.Text = "测试模式";
                SetTestControlsEnabled(false);
                txtTestAnswer.IsEnabled = false;
                UpdateTestScoreDisplay();
                return;
            }
            txtTestAnswer.IsEnabled = true;
            LoadNextTestQuestion();
            UpdateTestScoreDisplay(); // Initialize score display
        }

        private void LoadNextTestQuestion()
        {
            if (!wordList.Any())
            {
                txtTestQuestion.Text = "词库为空，测试已结束。";
                txtTestQuestionType.Text = "测试模式";
                SetTestControlsEnabled(false);
                txtTestAnswer.IsEnabled = false;
                return;
            }

            var eligibleWords = wordList.Where(w => !string.IsNullOrWhiteSpace(w.ChineseDefinition)).ToList();
            if (!eligibleWords.Any())
            {
                ShowError("测试题目错误", "词库中没有包含有效中文释义的单词进行测试。");
                txtTestQuestion.Text = "无法找到有效的测试题目。";
                SetTestControlsEnabled(false);
                txtTestAnswer.IsEnabled = false;
                return;
            }
            currentTestWord = eligibleWords[random.Next(eligibleWords.Count)];

            txtTestQuestionType.Text = "看中文释义写单词:";
            txtTestQuestion.Text = currentTestWord.ChineseDefinition;

            txtTestAnswer.Text = "";
            txtTestFeedback.Text = "";
            txtTestFeedback.Foreground = System.Windows.Media.Brushes.Black; // Reset feedback color
            txtTestAnswer.Focus();

            SetTestControlsEnabled(true);
            btnTestNextQuestion.IsEnabled = false;
            txtTestAnswer.IsEnabled = true;

            UpdateStatus($"测试模式: 请根据释义写出英文单词。");
        }

        private void SetTestControlsEnabled(bool enableQuestionRelated)
        {
            txtTestAnswer.IsEnabled = enableQuestionRelated;
            btnTestSubmit.IsEnabled = enableQuestionRelated;
            btnTestShowAnswer.IsEnabled = enableQuestionRelated;
        }

        private void BtnTestSubmit_Click(object sender, RoutedEventArgs e)
        {
            if (currentTestWord == null)
            {
                txtTestFeedback.Text = "没有当前测试题目。请按“下一题”。";
                txtTestFeedback.Foreground = System.Windows.Media.Brushes.Orange;
                return;
            }
            if (string.IsNullOrWhiteSpace(txtTestAnswer.Text))
            {
                txtTestFeedback.Text = "请输入答案。";
                txtTestFeedback.Foreground = System.Windows.Media.Brushes.Orange;
                return;
            }

            string userAnswer = txtTestAnswer.Text.Trim();
            bool isCorrect = userAnswer.Equals(currentTestWord.Word, StringComparison.OrdinalIgnoreCase);

            totalQuestionsAnswered++;
            if (isCorrect)
            {
                correctAnswers++;
                txtTestFeedback.Text = "回答正确！";
                txtTestFeedback.Foreground = System.Windows.Media.Brushes.Green;
            }
            else
            {
                txtTestFeedback.Text = $"回答错误。正确答案: {currentTestWord.Word}";
                txtTestFeedback.Foreground = System.Windows.Media.Brushes.Red;
                currentTestWord.TimesIncorrect++;
                AddWordToMistakes(currentTestWord);
            }

            UpdateTestScoreDisplay();
            btnTestSubmit.IsEnabled = false;
            btnTestShowAnswer.IsEnabled = false;
            btnTestNextQuestion.IsEnabled = true;
            txtTestAnswer.IsEnabled = false;
        }

        private void BtnTestShowAnswer_Click(object sender, RoutedEventArgs e)
        {
            if (currentTestWord == null) return;
            txtTestFeedback.Text = $"答案是: {currentTestWord.Word}";
            txtTestFeedback.Foreground = System.Windows.Media.Brushes.Blue;

            btnTestSubmit.IsEnabled = false;
            btnTestShowAnswer.IsEnabled = false;
            btnTestNextQuestion.IsEnabled = true;
            txtTestAnswer.IsEnabled = false;
        }

        private void BtnTestNextQuestion_Click(object sender, RoutedEventArgs e)
        {
            LoadNextTestQuestion();
        }

        private void UpdateTestScoreDisplay()
        {
            double accuracy = totalQuestionsAnswered > 0 ? (double)correctAnswers / totalQuestionsAnswered * 100 : 0;
            txtTestScore.Text = $"得分: {correctAnswers}/{totalQuestionsAnswered} (正确率: {accuracy:F1}%)";
        }

        private void TxtTestAnswer_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && btnTestSubmit.IsEnabled)
            {
                BtnTestSubmit_Click(sender, e);
            }
        }
        #endregion

        #region --- 错题本 ---
        private void AddWordToMistakes(WordItem wordFromMainList)
        {
            if (wordFromMainList == null) return;
            var existingMistake = mistakeList.FirstOrDefault(w => w.Word.Equals(wordFromMainList.Word, StringComparison.OrdinalIgnoreCase));
            if (existingMistake != null)
            {
                if (existingMistake.TimesIncorrect != wordFromMainList.TimesIncorrect)
                {
                    existingMistake.TimesIncorrect = wordFromMainList.TimesIncorrect;
                    // Forcing ObservableCollection to notice the change if UI doesn't update for property change
                    var itemIndex = mistakeList.IndexOf(existingMistake);
                    if (itemIndex >= 0 && itemIndex < mistakeList.Count)
                    { // Bounds check
                        mistakeList.RemoveAt(itemIndex);
                        mistakeList.Insert(itemIndex, existingMistake);
                    }
                    else
                    {
                        lvWrongWords.Items.Refresh(); // Fallback refresh
                    }
                    UpdateStatus($"单词 '{wordFromMainList.Word}' 答错次数已更新至 {existingMistake.TimesIncorrect}。");
                }
            }
            else
            {
                mistakeList.Add(wordFromMainList);
                UpdateStatus($"单词 '{wordFromMainList.Word}' 已添加至错题本。");
            }
            UpdateMistakeListControls();
            UpdateWordCountStatus();
        }

        private void LvWrongWords_SelectionChanged(object sender, SelectionChangedEventArgs e) { UpdateMistakeListControls(); }

        private void UpdateMistakeListControls()
        {
            bool isSelected = lvWrongWords.SelectedItem != null;
            btnReviewWrongWord.IsEnabled = isSelected;
            btnRemoveFromWrongWords.IsEnabled = isSelected;
            btnClearWrongWords.IsEnabled = mistakeList.Any();
        }
        private void BtnReviewWrongWord_Click(object sender, RoutedEventArgs e)
        {
            if (lvWrongWords.SelectedItem is WordItem selectedWord)
            {
                int indexInLearnList = wordList.FindIndex(w => w.Word.Equals(selectedWord.Word, StringComparison.OrdinalIgnoreCase));
                if (indexInLearnList != -1)
                {
                    currentLearnIndex = indexInLearnList;
                    if (mainTabControl != null && mainTabControl.Items.Count > 0) mainTabControl.SelectedIndex = 0;
                    DisplayCurrentLearnWord();
                }
                else { ShowError("复习错误", "选中的单词不在主学习列表中。"); }
            }
        }
        private void BtnRemoveFromWrongWords_Click(object sender, RoutedEventArgs e)
        {
            if (lvWrongWords.SelectedItem is WordItem selectedWord)
            {
                mistakeList.Remove(selectedWord);
                UpdateStatus($"单词 '{selectedWord.Word}' 已从错题本移除。");
                UpdateMistakeListControls(); UpdateWordCountStatus();
            }
        }
        private void BtnClearWrongWords_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("确定要清空错题本吗？此操作不可恢复。", "确认清空", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                mistakeList.Clear();
                UpdateStatus("错题本已清空。");
                UpdateMistakeListControls(); UpdateWordCountStatus();
            }
        }
        #endregion

        #region --- API 调用和数据处理 ---
        private async Task<WordItem> GetWordFromZhipu()
        {
            try
            {
                string existingWordsHint = "";
                if (wordList.Any())
                {
                    var recentWords = wordList.TakeLast(Math.Min(5, wordList.Count)).Select(w => w.Word);
                    existingWordsHint = $"请确保新生成的单词与最近的这些词汇（例如: {string.Join(", ", recentWords)}）明显不同。";
                }

                string userPrompt = $"请为我随机提供一个全新的英语四六级词汇。{existingWordsHint} " +
                                    "返回信息应包括：单词 (word)，美式音标 (phonetic)，" +
                                    "一个简短的中文释义 (chineseDefinition)，一个相关的英文例句 (example)，" +
                                    "以及一个用于生成相关助记图片的简短英文描述 (imageDescription)。" +
                                    "请严格以JSON格式返回，不要包含任何JSON标记之外的文本、注释或代码块标记。务必只返回JSON对象本身。" +
                                   $"例如：{{\"word\":\"novel\",\"phonetic\":\"[ˈnɑːvəl]\",\"chineseDefinition\":\"新奇的；小说\",\"example\":\"She had a novel approach to the problem.\",\"imageDescription\":\"An open book with glowing, imaginative scenes emerging from its pages\"}}. 当前时间戳（用于确保不同请求）: {DateTime.UtcNow.Ticks}";

                var requestPayload = new { model = modelName, messages = new[] { new { role = "user", content = userPrompt } }, temperature = 0.8, stream = false };
                string jsonRequest = JsonSerializer.Serialize(requestPayload);
                var httpContent = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                if (string.IsNullOrEmpty(apiKey) || apiKey == "YOUR_API_KEY")
                {
                    ShowError("API请求错误", "API密钥未配置。无法获取单词。");
                    return null;
                }
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                HttpResponseMessage response = await httpClient.PostAsync(textApiEndpoint, httpContent);
                string responseJson = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"[文本API状态码] {response.StatusCode}");
                // Log a smaller snippet of the response to avoid overly long console messages
                Console.WriteLine($"[文本API响应原始片段] {(responseJson.Length > 300 ? responseJson.Substring(0, 300) + "..." : responseJson)}");


                if (!response.IsSuccessStatusCode)
                {
                    ShowError("API文本请求失败", $"状态码: {response.StatusCode}. 响应: {(responseJson.Length > 250 ? responseJson.Substring(0, 250) + "..." : responseJson)}");
                    return null;
                }
                if (string.IsNullOrWhiteSpace(responseJson))
                {
                    ShowError("API文本请求失败", "API返回内容为空！");
                    return null;
                }

                var zhipuResponse = JsonSerializer.Deserialize<ZhipuV4TextResponse>(responseJson);
                if (zhipuResponse?.choices == null || zhipuResponse.choices.Length == 0 || string.IsNullOrWhiteSpace(zhipuResponse.choices[0]?.message?.content))
                {
                    ShowError("API文本请求失败", "API返回内容格式不正确或内容为空。");
                    return null;
                }

                string rawContent = zhipuResponse.choices[0].message.content;
                string cleanedJson = ExtractJsonFromString(rawContent);

                var wordData = JsonSerializer.Deserialize<WordInfoFromApi>(cleanedJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                if (wordData == null || string.IsNullOrEmpty(wordData.Word) || string.IsNullOrEmpty(wordData.ChineseDefinition))
                {
                    ShowError("API数据解析错误", $"无法从API响应中解析完整的单词信息 (word, chineseDefinition): {(cleanedJson.Length > 150 ? cleanedJson.Substring(0, 150) + "..." : cleanedJson)}");
                    return null;
                }

                string imageUrl = await GenerateImageFromZhipu(wordData.ImageDescription ?? $"An image related to {wordData.Word}");
                return new WordItem
                {
                    Word = wordData.Word.Trim(),
                    Phonetic = wordData.Phonetic?.Trim() ?? "[N/A]",
                    ChineseDefinition = wordData.ChineseDefinition?.Trim() ?? "无中文释义",
                    Example = wordData.Example?.Trim() ?? "无例句",
                    ImageUrl = imageUrl,
                    LearningDate = DateTime.Now
                };
            }
            catch (JsonException jsonEx)
            {
                // Provide more context for JsonException if possible
                string snippet = jsonEx.Path ?? (jsonEx.LineNumber > 0 ? $"Line {jsonEx.LineNumber}, Pos {jsonEx.BytePositionInLine}" : "N/A");
                ShowError("API数据解析错误", $"JSON解析失败: {jsonEx.Message}. Context: {snippet}.");
                return null;
            }
            catch (HttpRequestException httpEx) { ShowError("网络请求错误", $"无法连接到API服务: {httpEx.Message}"); return null; }
            catch (TaskCanceledException tcEx) when (tcEx.InnerException is TimeoutException) // More specific timeout handling
            { ShowError("网络请求超时", $"API请求超时 ({(int)httpClient.Timeout.TotalSeconds}s): {tcEx.Message}"); return null; }
            catch (TaskCanceledException tcEx) // General TaskCanceled (could be from CancellationToken)
            { ShowError("操作已取消", $"操作已取消: {tcEx.Message}"); return null; }
            catch (Exception ex) { ShowError("获取单词时出错", $"发生意外错误: {ex.Message}\n{ex.StackTrace}"); return null; }
        }

        private string ExtractJsonFromString(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return "{}"; // Should not happen with valid API

            input = input.Trim();

            // Handle ```json ... ``` markdown
            if (input.StartsWith("```json", StringComparison.OrdinalIgnoreCase))
            {
                input = input.Substring(input.IndexOf('{')); // Start from first '{'
                if (input.EndsWith("```"))
                {
                    input = input.Substring(0, input.LastIndexOf('}') + 1); // End at last '}'
                }
            }
            // Handle ``` ... ``` markdown
            else if (input.StartsWith("```"))
            {
                input = input.Substring(input.IndexOf('{'));
                if (input.EndsWith("```"))
                {
                    input = input.Substring(0, input.LastIndexOf('}') + 1);
                }
            }
            input = input.Trim(); // Trim again after potential markdown removal

            int firstBrace = input.IndexOf('{');
            int lastBrace = input.LastIndexOf('}');

            if (firstBrace == 0 && lastBrace == input.Length - 1) // Simple case: already a JSON object
            {
                return input;
            }
            if (firstBrace != -1 && lastBrace != -1 && lastBrace > firstBrace) // Embedded JSON
            {
                return input.Substring(firstBrace, lastBrace - firstBrace + 1);
            }

            Console.WriteLine($"[JSON Extraction Warning] Could not reliably extract JSON object from: {(input.Length > 100 ? input.Substring(0, 100) + "..." : input)}");
            // If extraction is problematic, returning the input and letting JsonSerializer try is an option,
            // but it's better if the API is consistent.
            return input;
        }

        private async Task<string> GenerateImageFromZhipu(string description)
        {
            if (string.IsNullOrWhiteSpace(description)) description = "A neutral background image.";
            string fallbackImageUrl = $"https://picsum.photos/600/150?text=Image+Gen+Error&random={Guid.NewGuid()}";
            try
            {
                if (string.IsNullOrEmpty(apiKey) || apiKey == "YOUR_API_KEY")
                {
                    Console.WriteLine("[图片API请求错误] API密钥未配置。");
                    return fallbackImageUrl;
                }
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

                var requestPayload = new { model = imageModelName, prompt = description, n = 1, size = "1024x576" };
                string jsonRequest = JsonSerializer.Serialize(requestPayload);
                var httpContent = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await httpClient.PostAsync(imageApiEndpoint, httpContent);
                string responseJson = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"图片API请求失败: {response.StatusCode} - {(responseJson.Length > 100 ? responseJson.Substring(0, 100) + "..." : responseJson)}");
                    return fallbackImageUrl;
                }

                using JsonDocument doc = JsonDocument.Parse(responseJson);
                JsonElement root = doc.RootElement;
                if (root.TryGetProperty("data", out JsonElement dataArray) && dataArray.ValueKind == JsonValueKind.Array && dataArray.GetArrayLength() > 0)
                {
                    if (dataArray[0].TryGetProperty("url", out JsonElement urlElement) && urlElement.ValueKind == JsonValueKind.String)
                    {
                        string url = urlElement.GetString();
                        if (!string.IsNullOrEmpty(url)) return url;
                    }
                }
                Console.WriteLine("图片API未按预期格式返回URL.");
                return fallbackImageUrl;
            }
            catch (JsonException jsonEx) { Console.WriteLine($"[图片生成JSON错误] Prompt: '{(description.Length > 50 ? description.Substring(0, 50) + "..." : description)}', Error: {jsonEx.Message}"); return fallbackImageUrl; }
            catch (HttpRequestException httpEx) { Console.WriteLine($"[图片生成网络错误] Prompt: '{(description.Length > 50 ? description.Substring(0, 50) + "..." : description)}', Error: {httpEx.Message}"); return fallbackImageUrl; }
            catch (TaskCanceledException tcEx) when (tcEx.InnerException is TimeoutException)
            { Console.WriteLine($"[图片生成超时] Prompt: '{(description.Length > 50 ? description.Substring(0, 50) + "..." : description)}', Error: {tcEx.Message}"); return fallbackImageUrl; }
            catch (TaskCanceledException tcEx)
            { Console.WriteLine($"[图片生成操作取消] Prompt: '{(description.Length > 50 ? description.Substring(0, 50) + "..." : description)}', Error: {tcEx.Message}"); return fallbackImageUrl; }
            catch (Exception ex) { Console.WriteLine($"[图片生成错误] Prompt: '{(description.Length > 50 ? description.Substring(0, 50) + "..." : description)}', Error: {ex.Message}"); return fallbackImageUrl; }
        }

        private async void LoadImage(string imageUrl, Image targetImageControl, TextBlock loadingTextBlock)
        {
            if (targetImageControl == null) return;
            string fallbackImgUri = $"https://picsum.photos/600/150?text=Image+Load+Issue&random={Guid.NewGuid()}";

            try
            {
                if (loadingTextBlock != null) loadingTextBlock.Visibility = Visibility.Visible;
                targetImageControl.Source = null;

                if (string.IsNullOrEmpty(imageUrl) || !Uri.IsWellFormedUriString(imageUrl, UriKind.Absolute))
                {
                    Console.WriteLine($"[图片加载] 无效或空的图片URL: '{imageUrl}'");
                    targetImageControl.Source = new BitmapImage(new Uri(fallbackImgUri));
                    if (loadingTextBlock != null) loadingTextBlock.Visibility = Visibility.Collapsed; // Hide loading text for fallback
                    return;
                }

                BitmapImage bitmap = null;
                Exception lastException = null;
                const int maxAttempts = 2;

                for (int attempt = 0; attempt < maxAttempts; attempt++)
                {
                    try
                    {
                        using var requestMessage = new HttpRequestMessage(HttpMethod.Get, new Uri(imageUrl, UriKind.Absolute));
                        using var responseMsg = await httpClient.SendAsync(requestMessage, HttpCompletionOption.ResponseHeadersRead);
                        responseMsg.EnsureSuccessStatusCode();

                        using var stream = await responseMsg.Content.ReadAsStreamAsync();
                        var imageData = new MemoryStream();
                        await stream.CopyToAsync(imageData);
                        imageData.Position = 0;

                        bitmap = new BitmapImage();
                        bitmap.BeginInit();
                        bitmap.CacheOption = BitmapCacheOption.OnLoad;
                        bitmap.StreamSource = imageData;
                        bitmap.EndInit();
                        if (bitmap.CanFreeze) bitmap.Freeze();

                        break; // Success
                    }
                    catch (Exception ex)
                    {
                        lastException = ex;
                        Console.WriteLine($"[图片加载尝试 {attempt + 1}/{maxAttempts} 失败] URL: '{(imageUrl.Length > 70 ? imageUrl.Substring(0, 70) + "..." : imageUrl)}', Error: {ex.Message}.");
                        if (attempt < maxAttempts - 1) await Task.Delay(TimeSpan.FromSeconds(1));
                    }
                }

                if (bitmap != null)
                {
                    targetImageControl.Source = bitmap;
                }
                else
                {
                    throw lastException ?? new Exception($"多次尝试后图片加载失败 (URL: {(imageUrl.Length > 70 ? imageUrl.Substring(0, 70) + "..." : imageUrl)})。");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[图片加载最终错误] URL: '{imageUrl?.Substring(0, Math.Min(imageUrl?.Length ?? 0, 70))}', Error: {ex.Message}");
                targetImageControl.Source = new BitmapImage(new Uri(fallbackImgUri));
            }
            finally
            {
                if (loadingTextBlock != null) loadingTextBlock.Visibility = Visibility.Collapsed;
            }
        }
        #endregion

        #region --- UI 更新和辅助 ---
        private void UpdateStatus(string message)
        {
            Dispatcher.Invoke(() => { if (txtStatus != null) txtStatus.Text = message; });
            Console.WriteLine($"[Status] {message}");
        }
        private void UpdateWordCountStatus()
        {
            Dispatcher.Invoke(() =>
            {
                if (txtWordCount != null)
                {
                    int kC = wordList.Count(w => w.IsKnown);
                    txtWordCount.Text = $"已掌握: {kC} / 总词数: {wordList.Count} | 错题: {mistakeList.Count}";
                }
            });
        }
        private void ShowError(string title, string message)
        {
            message = message.Replace(apiKey, "[API_KEY_REDACTED]");
            Dispatcher.Invoke(() =>
            {
                if (txtError != null && errorPopup != null)
                {
                    txtError.Text = $"[{title}] {message}";
                    errorPopup.IsOpen = true;
                }
            });
            Console.WriteLine($"[Error] {title}: {message}");
        }
        private void BtnCloseError_Click(object sender, RoutedEventArgs e)
        {
            if (errorPopup != null) errorPopup.IsOpen = false;
        }
        private void MainTabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.Source is TabControl tc && tc.Name == "mainTabControl")
            {
                if (tc.SelectedItem is TabItem selectedTab)
                {
                    string header = selectedTab.Header?.ToString();
                    if (header == "测试模式")
                    {
                        PrepareFirstTestQuestion();
                    }
                    else if (header == "错题本")
                    {
                        lvWrongWords.Items.Refresh();
                        UpdateMistakeListControls();
                    }
                    else if (header == "学习模式")
                    {
                        if (wordList.Any()) DisplayCurrentLearnWord();
                        else ClearLearnWordDisplay();
                    }
                }
            }
        }
        #endregion

        #region Loading Popup
        private void ShowLoading(string message = "加载中，请稍候...")
        {
            Dispatcher.Invoke(() =>
            {
                if (loadingIndicatorPopupText != null) loadingIndicatorPopupText.Text = message;
                if (loadingIndicatorProgressBar != null) loadingIndicatorProgressBar.Visibility = Visibility.Visible;
                if (loadingIndicatorPopup != null) loadingIndicatorPopup.IsOpen = true;
                this.IsEnabled = false;
            });
        }
        private void UpdateLoadingMessage(string message)
        {
            Dispatcher.Invoke(() => { if (loadingIndicatorPopupText != null) loadingIndicatorPopupText.Text = message; });
        }
        private void HideLoading()
        {
            Dispatcher.Invoke(() =>
            {
                if (loadingIndicatorPopup != null) loadingIndicatorPopup.IsOpen = false;
                this.IsEnabled = true;
            });
        }
        #endregion

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            httpClient?.Dispose();
            base.OnClosing(e);
        }
    }
}