﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Animation;

namespace CETWordMemory
{
    public enum StartupMode
    {
        Learn,
        Test,
        Mistakes
    }

    public partial class IntroWindow : Window
    {
        public IntroWindow()
        {
            InitializeComponent();
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                this.DragMove();
            }
        }

        private void LaunchMainWindow(StartupMode mode)
        {
            // Ensure this.Resources is not null and the key exists
            if (this.Resources != null && this.Resources.Contains("WindowFadeOut"))
            {
                Storyboard fadeOutStoryboard = (Storyboard)this.Resources["WindowFadeOut"];
                fadeOutStoryboard.Completed += (s, e_args) => // Renamed 'e' to 'e_args' to avoid conflict
                {
                    MainWindow mainWindow = new MainWindow(mode);
                    mainWindow.Show();
                    this.Close();
                };
                fadeOutStoryboard.Begin(this);
            }
            else // Fallback if storyboard not found or resources are null
            {
                MainWindow mainWindow = new MainWindow(mode);
                mainWindow.Show();
                this.Close();
            }
        }

        private void BtnLearnMode_Click(object sender, RoutedEventArgs e)
        {
            LaunchMainWindow(StartupMode.Learn);
        }

        private void BtnTestMode_Click(object sender, RoutedEventArgs e)
        {
            LaunchMainWindow(StartupMode.Test);
        }

        private void BtnMistakesMode_Click(object sender, RoutedEventArgs e)
        {
            LaunchMainWindow(StartupMode.Mistakes);
        }
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            // Optionally, add a fade out animation here too before shutting down
            Application.Current.Shutdown();
        }
    }
}