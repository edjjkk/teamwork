﻿namespace CETVocabularyApp
{
    public class Word
    {
        public string English { get; set; }
        public string Chinese { get; set; }
        public string Example { get; set; }

        public Word(string english, string chinese, string example)
        {
            English = english;
            Chinese = chinese;
            Example = example;
        }
    }
}