﻿using System.Collections.Generic;

namespace CETVocabularyApp.Services
{
    public static class WordDataService
    {
        public static List<Word> LoadCET4Words()
        {
            return new List<Word>
            {
                new Word("abandon", "放弃，遗弃", "He abandoned his car and ran away."),
                new Word("ability", "能力，才能", "She has the ability to solve complex problems."),
                // 添加更多单词...
            };
        }

        public static List<Word> LoadCET6Words()
        {
            return new List<Word>
            {
                new Word("abnormal", "反常的，异常的", "His abnormal behavior worried his friends."),
                new Word("abolish", "废除，废止", "The government abolished the outdated law."),
                // 添加更多单词...
            };
        }
    }
}