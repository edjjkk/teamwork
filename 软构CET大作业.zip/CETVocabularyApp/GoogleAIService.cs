﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using Newtonsoft.Json;
using System.IO;
using System.Text;
using CETVocabularyApp.Helpers;

namespace CETVocabularyApp.Services
{
    public class GoogleAIService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey = "AIzaSyDk4xDVRIQMTTV27dMfd5C6oqPxZDiT9dQ";
        private readonly string _baseUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent";

        public GoogleAIService()
        {
            _httpClient = new HttpClient();
        }

        public async Task<string> GenerateImagePrompt(string word, string meaning)
        {
            try
            {
                var requestBody = new
                {
                    contents = new[]
                    {
                        new
                        {
                            parts = new[]
                            {
                                new
                                {
                                    text = $"Generate a detailed prompt for an image that helps remember the English word '{word}' which means '{meaning}'. " +
                                           "The image should be simple, clear, colorful and memorable. " +
                                           "Provide only the prompt text, no additional explanations."
                                }
                            }
                        }
                    }
                };

                var json = JsonConvert.SerializeObject(requestBody);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync($"{_baseUrl}?key={_apiKey}", content);
                response.EnsureSuccessStatusCode();

                var responseJson = await response.Content.ReadAsStringAsync();
                dynamic responseData = JsonConvert.DeserializeObject(responseJson);

                return responseData.candidates[0].content.parts[0].text;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"生成提示时出错: {ex.Message}");
                return null;
            }
        }

        public async Task<BitmapImage> GenerateWordImageAsync(string word, string meaning)
        {
            try
            {
                // 第一步：生成图片描述
                var prompt = await GenerateImagePrompt(word, meaning);
                if (string.IsNullOrEmpty(prompt))
                {
                    prompt = $"A clear image to remember the English word '{word}' meaning '{meaning}'";
                }

                // 第二步：这里需要调用图像生成API
                // 注意：Google AI Studio目前主要提供文本生成，图像生成可能需要其他服务
                // 以下是模拟实现，实际使用时需要替换为真实的图像生成API调用

                // 模拟延迟
                await Task.Delay(1000);

                // 返回占位图（实际项目应调用真实图像API）
                return ImageHelper.GetPlaceholderImage();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"生成图片时出错: {ex.Message}");
                return null;
            }
        }
    }
}