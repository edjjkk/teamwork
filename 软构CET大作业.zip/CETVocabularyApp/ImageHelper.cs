﻿using System;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace CETVocabularyApp.Helpers
{
    public static class ImageHelper
    {
        public static BitmapImage GetPlaceholderImage()
        {
            return LoadImageFromResource("Assets/placeholder.png");
        }

        public static BitmapImage GetLoadingImage()
        {
            return LoadImageFromResource("Assets/loading.png");
        }

        public static BitmapImage GetErrorImage()
        {
            return LoadImageFromResource("Assets/error.png");
        }

        private static BitmapImage LoadImageFromResource(string path)
        {
            try
            {
                return new BitmapImage(new Uri($"pack://application:,,,/{path}"));
            }
            catch
            {
                // 创建简单的纯色备用图像
                return CreateSolidColorBitmap(512, 512, Colors.LightGray);
            }
        }

        private static BitmapImage CreateSolidColorBitmap(int width, int height, Color color)
        {
            var stride = width * 4;
            var pixels = new byte[height * stride];

            for (int i = 0; i < pixels.Length; i += 4)
            {
                pixels[i] = color.B;     // Blue
                pixels[i + 1] = color.G;   // Green
                pixels[i + 2] = color.R;    // Red
                pixels[i + 3] = color.A;   // Alpha
            }

            // 修正这里，先创建BitmapSource，再转换为BitmapImage
            BitmapSource bitmapSource = BitmapSource.Create(
                width, height, 96, 96,
                System.Windows.Media.PixelFormats.Bgra32,
                null, pixels, stride);

            BitmapImage bitmapImage = new BitmapImage();
            bitmapImage.BeginInit();
            // 使用MemoryStream进行转换
            using (MemoryStream memoryStream = new MemoryStream())
            {
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bitmapSource));
                encoder.Save(memoryStream);
                memoryStream.Seek(0, SeekOrigin.Begin);
                bitmapImage.StreamSource = memoryStream;
            }
            bitmapImage.EndInit();
            bitmapImage.Freeze();
            return bitmapImage;
        }
    }
}